"use client";

import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Calendar, Clock, Dumbbell, Heart, Plus, TrendingUp, Activity, Target, Zap, Moon, Sun } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, ResponsiveContainer } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { useTheme } from 'next-themes';

// Data types
interface Exercise {
  id: string;
  name: string;
  category: string;
  muscleGroup: string;
}

interface WorkoutSet {
  reps: number;
  weight: number;
  restTime?: number;
}

interface WorkoutExercise {
  exerciseId: string;
  exerciseName: string;
  sets: WorkoutSet[];
  notes?: string;
}

interface Workout {
  id: string;
  date: string;
  name: string;
  exercises: WorkoutExercise[];
  duration: number;
  notes?: string;
}

interface Run {
  id: string;
  date: string;
  distance: number;
  duration: number;
  pace: number;
  type: string;
  notes?: string;
  route?: string;
}

interface BodyMeasurement {
  date: string;
  weight: number;
  bodyFat?: number;
}

// Exercise library
const exerciseLibrary: Exercise[] = [
  { id: '1', name: 'Bench Press', category: 'Strength', muscleGroup: 'Chest' },
  { id: '2', name: 'Squat', category: 'Strength', muscleGroup: 'Legs' },
  { id: '3', name: 'Deadlift', category: 'Strength', muscleGroup: 'Back' },
  { id: '4', name: 'Overhead Press', category: 'Strength', muscleGroup: 'Shoulders' },
  { id: '5', name: 'Barbell Row', category: 'Strength', muscleGroup: 'Back' },
  { id: '6', name: 'Pull-up', category: 'Strength', muscleGroup: 'Back' },
  { id: '7', name: 'Dips', category: 'Strength', muscleGroup: 'Chest' },
  { id: '8', name: 'Bicep Curl', category: 'Isolation', muscleGroup: 'Arms' },
  { id: '9', name: 'Tricep Extension', category: 'Isolation', muscleGroup: 'Arms' },
  { id: '10', name: 'Leg Press', category: 'Strength', muscleGroup: 'Legs' },
];

// Run types
const runTypes = ['Easy', 'Tempo', 'Intervals', 'Long Run', 'Recovery', 'Race'];

export default function FitnessTracker() {
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [runs, setRuns] = useState<Run[]>([]);
  const [bodyMeasurements, setBodyMeasurements] = useState<BodyMeasurement[]>([]);
  const [showWorkoutDialog, setShowWorkoutDialog] = useState(false);
  const [showRunDialog, setShowRunDialog] = useState(false);
  const [currentWorkout, setCurrentWorkout] = useState<Partial<Workout>>({ exercises: [] });
  const [currentRun, setCurrentRun] = useState<Partial<Run>>({});

  // Ensure component is mounted before accessing theme
  useEffect(() => {
    setMounted(true);
  }, []);

  const toggleTheme = () => {
    setTheme(theme === 'light' ? 'dark' : 'light');
  };

  // Load data from localStorage on mount
  useEffect(() => {
    const savedWorkouts = localStorage.getItem('workouts');
    const savedRuns = localStorage.getItem('runs');
    const savedMeasurements = localStorage.getItem('bodyMeasurements');

    if (savedWorkouts) setWorkouts(JSON.parse(savedWorkouts));
    if (savedRuns) setRuns(JSON.parse(savedRuns));
    if (savedMeasurements) setBodyMeasurements(JSON.parse(savedMeasurements));
  }, []);

  // Save data to localStorage when it changes
  useEffect(() => {
    localStorage.setItem('workouts', JSON.stringify(workouts));
  }, [workouts]);

  useEffect(() => {
    localStorage.setItem('runs', JSON.stringify(runs));
  }, [runs]);

  useEffect(() => {
    localStorage.setItem('bodyMeasurements', JSON.stringify(bodyMeasurements));
  }, [bodyMeasurements]);

  // Calculate stats
  const totalWorkouts = workouts.length;
  const totalRuns = runs.length;
  const totalVolume = workouts.reduce((sum, workout) => 
    sum + workout.exercises.reduce((exerciseSum, exercise) => 
      exerciseSum + exercise.sets.reduce((setSum, set) => setSum + (set.reps * set.weight), 0), 0), 0);
  const totalDistance = runs.reduce((sum, run) => sum + run.distance, 0);

  const recentWorkouts = workouts.slice(-3).reverse();
  const recentRuns = runs.slice(-3).reverse();

  const addExerciseToWorkout = (exerciseId: string) => {
    const exercise = exerciseLibrary.find(e => e.id === exerciseId);
    if (exercise) {
      setCurrentWorkout(prev => ({
        ...prev,
        exercises: [...(prev.exercises || []), {
          exerciseId,
          exerciseName: exercise.name,
          sets: [{ reps: 0, weight: 0 }]
        }]
      }));
    }
  };

  const updateSet = (exerciseIndex: number, setIndex: number, field: keyof WorkoutSet, value: number) => {
    setCurrentWorkout(prev => {
      const newExercises = [...(prev.exercises || [])];
      newExercises[exerciseIndex].sets[setIndex] = {
        ...newExercises[exerciseIndex].sets[setIndex],
        [field]: value
      };
      return { ...prev, exercises: newExercises };
    });
  };

  const addSet = (exerciseIndex: number) => {
    setCurrentWorkout(prev => {
      const newExercises = [...(prev.exercises || [])];
      newExercises[exerciseIndex].sets.push({ reps: 0, weight: 0 });
      return { ...prev, exercises: newExercises };
    });
  };

  const saveWorkout = () => {
    if (currentWorkout.name && currentWorkout.exercises && currentWorkout.exercises.length > 0) {
      const newWorkout: Workout = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        name: currentWorkout.name,
        exercises: currentWorkout.exercises,
        duration: currentWorkout.duration || 0,
        notes: currentWorkout.notes
      };
      setWorkouts(prev => [...prev, newWorkout]);
      setCurrentWorkout({ exercises: [] });
      setShowWorkoutDialog(false);
    }
  };

  const saveRun = () => {
    if (currentRun.distance && currentRun.duration) {
      const newRun: Run = {
        id: Date.now().toString(),
        date: new Date().toISOString(),
        distance: currentRun.distance,
        duration: currentRun.duration,
        pace: currentRun.duration / currentRun.distance,
        type: currentRun.type || 'Easy',
        notes: currentRun.notes,
        route: currentRun.route
      };
      setRuns(prev => [...prev, newRun]);
      setCurrentRun({});
      setShowRunDialog(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const formatPace = (pace: number) => {
    const mins = Math.floor(pace / 60);
    const secs = Math.round(pace % 60);
    return `${mins}:${secs.toString().padStart(2, '0')} /km`;
  };

  // Generate chart data
  const getWorkoutChartData = () => {
    const last7Workouts = workouts.slice(-7);
    return last7Workouts.map((workout, index) => ({
      name: `Workout ${index + 1}`,
      date: new Date(workout.date).toLocaleDateString(),
      volume: workout.exercises.reduce((sum, exercise) => 
        sum + exercise.sets.reduce((setSum, set) => setSum + (set.reps * set.weight), 0), 0),
      duration: workout.duration,
      exercises: workout.exercises.length
    }));
  };

  const getRunningChartData = () => {
    const last7Runs = runs.slice(-7);
    return last7Runs.map((run, index) => ({
      name: `Run ${index + 1}`,
      date: new Date(run.date).toLocaleDateString(),
      distance: run.distance,
      pace: run.pace / 60, // Convert to minutes for better visualization
      duration: run.duration / 60 // Convert to minutes
    }));
  };

  const getWeeklyStats = () => {
    const now = new Date();
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const weeklyWorkouts = workouts.filter(w => new Date(w.date) >= oneWeekAgo);
    const weeklyRuns = runs.filter(r => new Date(r.date) >= oneWeekAgo);
    
    return {
      workouts: weeklyWorkouts.length,
      runs: weeklyRuns.length,
      distance: weeklyRuns.reduce((sum, run) => sum + run.distance, 0)
    };
  };

  const weeklyStats = getWeeklyStats();
  const workoutChartData = getWorkoutChartData();
  const runningChartData = getRunningChartData();

  return (
    <div className="min-h-screen bg-background p-2 sm:p-4">
      <div className="max-w-4xl mx-auto">
        <header className="text-center mb-6 sm:mb-8 relative">
          <div className="absolute top-0 right-0">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="mr-2 h-10 w-10"
            >
              {mounted && theme === 'light' ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-primary mb-2">Fitness Tracker</h1>
          <p className="text-sm sm:text-base text-muted-foreground">Track your gym workouts and running progress</p>
        </header>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4 h-12 sm:h-auto">
            <TabsTrigger value="dashboard" className="text-xs sm:text-sm">Dashboard</TabsTrigger>
            <TabsTrigger value="gym" className="text-xs sm:text-sm">Gym</TabsTrigger>
            <TabsTrigger value="running" className="text-xs sm:text-sm">Running</TabsTrigger>
            <TabsTrigger value="progress" className="text-xs sm:text-sm">Progress</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="space-y-4 sm:space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
              <Card className="p-3 sm:p-6">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-0 sm:px-6">
                  <CardTitle className="text-xs sm:text-sm font-medium">Total Workouts</CardTitle>
                  <Dumbbell className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="px-0 sm:px-6 pt-0">
                  <div className="text-xl sm:text-2xl font-bold">{totalWorkouts}</div>
                </CardContent>
              </Card>
              <Card className="p-3 sm:p-6">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-0 sm:px-6">
                  <CardTitle className="text-xs sm:text-sm font-medium">Total Runs</CardTitle>
                  <Activity className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="px-0 sm:px-6 pt-0">
                  <div className="text-xl sm:text-2xl font-bold">{totalRuns}</div>
                </CardContent>
              </Card>
              <Card className="p-3 sm:p-6">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-0 sm:px-6">
                  <CardTitle className="text-xs sm:text-sm font-medium">Total Volume</CardTitle>
                  <Target className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="px-0 sm:px-6 pt-0">
                  <div className="text-xl sm:text-2xl font-bold">{totalVolume.toLocaleString()}kg</div>
                </CardContent>
              </Card>
              <Card className="p-3 sm:p-6">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 px-0 sm:px-6">
                  <CardTitle className="text-xs sm:text-sm font-medium">Total Distance</CardTitle>
                  <Zap className="h-3 w-3 sm:h-4 sm:w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent className="px-0 sm:px-6 pt-0">
                  <div className="text-xl sm:text-2xl font-bold">{totalDistance.toFixed(1)}km</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid md:grid-cols-2 gap-4 sm:gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-base sm:text-lg">Recent Workouts</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Your latest gym sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-48 sm:h-64">
                    {recentWorkouts.length === 0 ? (
                      <p className="text-muted-foreground text-center py-4 text-sm">No workouts yet</p>
                    ) : (
                      <div className="space-y-3">
                        {recentWorkouts.map(workout => (
                          <div key={workout.id} className="border rounded-lg p-3">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium text-sm">{workout.name}</h4>
                              <Badge variant="secondary" className="text-xs">{formatTime(workout.duration)}</Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {workout.exercises.length} exercises • {new Date(workout.date).toLocaleDateString()}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-base sm:text-lg">Recent Runs</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">Your latest running sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-48 sm:h-64">
                    {recentRuns.length === 0 ? (
                      <p className="text-muted-foreground text-center py-4 text-sm">No runs yet</p>
                    ) : (
                      <div className="space-y-3">
                        {recentRuns.map(run => (
                          <div key={run.id} className="border rounded-lg p-3">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium text-sm">{run.type} Run</h4>
                              <Badge variant="secondary" className="text-xs">{formatPace(run.pace)}</Badge>
                            </div>
                            <p className="text-xs text-muted-foreground">
                              {run.distance}km • {formatTime(run.duration)} • {new Date(run.date).toLocaleDateString()}
                            </p>
                          </div>
                        ))}
                      </div>
                    )}
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="gym" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Gym Workouts</h2>
              <Dialog open={showWorkoutDialog} onOpenChange={setShowWorkoutDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Workout
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                  <DialogHeader>
                    <DialogTitle>New Workout</DialogTitle>
                    <DialogDescription>Log your gym workout</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="workout-name">Workout Name</Label>
                      <Input
                        id="workout-name"
                        value={currentWorkout.name || ''}
                        onChange={(e) => setCurrentWorkout(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="e.g., Upper Body Day"
                      />
                    </div>
                    <div>
                      <Label htmlFor="duration">Duration (minutes)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={currentWorkout.duration || ''}
                        onChange={(e) => setCurrentWorkout(prev => ({ ...prev, duration: parseInt(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <Label>Add Exercises</Label>
                      <Select onValueChange={addExerciseToWorkout}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select an exercise" />
                        </SelectTrigger>
                        <SelectContent>
                          {exerciseLibrary.map(exercise => (
                            <SelectItem key={exercise.id} value={exercise.id}>
                              {exercise.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-4">
                      {currentWorkout.exercises?.map((exercise, exerciseIndex) => (
                        <Card key={exerciseIndex}>
                          <CardHeader>
                            <CardTitle className="text-lg">{exercise.exerciseName}</CardTitle>
                          </CardHeader>
                          <CardContent>
                            <div className="space-y-3">
                              {exercise.sets.map((set, setIndex) => (
                                <div key={setIndex} className="grid grid-cols-3 gap-2">
                                  <div>
                                    <Label>Reps</Label>
                                    <Input
                                      type="number"
                                      value={set.reps}
                                      onChange={(e) => updateSet(exerciseIndex, setIndex, 'reps', parseInt(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label>Weight (kg)</Label>
                                    <Input
                                      type="number"
                                      value={set.weight}
                                      onChange={(e) => updateSet(exerciseIndex, setIndex, 'weight', parseInt(e.target.value))}
                                    />
                                  </div>
                                  <div>
                                    <Label>Rest (s)</Label>
                                    <Input
                                      type="number"
                                      value={set.restTime || ''}
                                      onChange={(e) => updateSet(exerciseIndex, setIndex, 'restTime', parseInt(e.target.value))}
                                    />
                                  </div>
                                </div>
                              ))}
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => addSet(exerciseIndex)}
                              >
                                <Plus className="h-4 w-4 mr-2" />
                                Add Set
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                    <div>
                      <Label htmlFor="notes">Notes</Label>
                      <Textarea
                        id="notes"
                        value={currentWorkout.notes || ''}
                        onChange={(e) => setCurrentWorkout(prev => ({ ...prev, notes: e.target.value }))}
                        placeholder="How did the workout feel?"
                      />
                    </div>
                    <Button onClick={saveWorkout} className="w-full">
                      Save Workout
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-4">
              {workouts.slice().reverse().map(workout => (
                <Card key={workout.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{workout.name}</CardTitle>
                        <CardDescription>
                          {new Date(workout.date).toLocaleDateString()} • {formatTime(workout.duration)}
                        </CardDescription>
                      </div>
                      <Badge>{workout.exercises.length} exercises</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {workout.exercises.map((exercise, index) => (
                        <div key={index} className="border-l-2 border-primary pl-3">
                          <h4 className="font-medium">{exercise.exerciseName}</h4>
                          <div className="text-sm text-muted-foreground">
                            {exercise.sets.map((set, setIndex) => (
                              <span key={setIndex}>
                                {set.reps} × {set.weight}kg{setIndex < exercise.sets.length - 1 ? ', ' : ''}
                              </span>
                            ))}
                          </div>
                          {exercise.notes && (
                            <p className="text-sm text-muted-foreground mt-1">{exercise.notes}</p>
                          )}
                        </div>
                      ))}
                      {workout.notes && (
                        <div className="mt-3 p-2 bg-muted rounded">
                          <p className="text-sm">{workout.notes}</p>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="running" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Running</h2>
              <Dialog open={showRunDialog} onOpenChange={setShowRunDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <Plus className="h-4 w-4 mr-2" />
                    New Run
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>New Run</DialogTitle>
                    <DialogDescription>Log your running session</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="distance">Distance (km)</Label>
                      <Input
                        id="distance"
                        type="number"
                        step="0.1"
                        value={currentRun.distance || ''}
                        onChange={(e) => setCurrentRun(prev => ({ ...prev, distance: parseFloat(e.target.value) }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="duration">Duration (minutes)</Label>
                      <Input
                        id="duration"
                        type="number"
                        value={currentRun.duration || ''}
                        onChange={(e) => setCurrentRun(prev => ({ ...prev, duration: parseInt(e.target.value) * 60 }))}
                      />
                    </div>
                    <div>
                      <Label htmlFor="type">Run Type</Label>
                      <Select onValueChange={(value) => setCurrentRun(prev => ({ ...prev, type: value }))}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select run type" />
                        </SelectTrigger>
                        <SelectContent>
                          {runTypes.map(type => (
                            <SelectItem key={type} value={type}>
                              {type}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="route">Route (optional)</Label>
                      <Input
                        id="route"
                        value={currentRun.route || ''}
                        onChange={(e) => setCurrentRun(prev => ({ ...prev, route: e.target.value }))}
                        placeholder="e.g., Park Loop"
                      />
                    </div>
                    <div>
                      <Label htmlFor="run-notes">Notes</Label>
                      <Textarea
                        id="run-notes"
                        value={currentRun.notes || ''}
                        onChange={(e) => setCurrentRun(prev => ({ ...prev, notes: e.target.value }))}
                        placeholder="How did the run feel?"
                      />
                    </div>
                    <Button onClick={saveRun} className="w-full">
                      Save Run
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </div>

            <div className="space-y-4">
              {runs.slice().reverse().map(run => (
                <Card key={run.id}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle>{run.type} Run</CardTitle>
                        <CardDescription>
                          {new Date(run.date).toLocaleDateString()} • {run.route}
                        </CardDescription>
                      </div>
                      <Badge variant="secondary">{formatPace(run.pace)}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <p className="text-sm text-muted-foreground">Distance</p>
                        <p className="text-lg font-semibold">{run.distance}km</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Duration</p>
                        <p className="text-lg font-semibold">{formatTime(run.duration)}</p>
                      </div>
                      <div>
                        <p className="text-sm text-muted-foreground">Pace</p>
                        <p className="text-lg font-semibold">{formatPace(run.pace)}</p>
                      </div>
                    </div>
                    {run.notes && (
                      <div className="mt-3 p-2 bg-muted rounded">
                        <p className="text-sm">{run.notes}</p>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <h2 className="text-2xl font-bold">Progress Tracking</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Workout Frequency</CardTitle>
                  <CardDescription>Your weekly workout consistency</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>This Week</span>
                      <span>{weeklyStats.workouts} workouts</span>
                    </div>
                    <Progress value={(weeklyStats.workouts / 4) * 100} className="h-2" />
                    <p className="text-xs text-muted-foreground">Goal: 4 workouts per week</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Running Progress</CardTitle>
                  <CardDescription>Your weekly running distance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>This Week</span>
                      <span>{weeklyStats.distance.toFixed(1)} km</span>
                    </div>
                    <Progress value={(weeklyStats.distance / 20) * 100} className="h-2" />
                    <p className="text-xs text-muted-foreground">Goal: 20 km per week</p>
                  </div>
                </CardContent>
              </Card>
            </div>

            {workoutChartData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Workout Volume Trend</CardTitle>
                  <CardDescription>Your lifting volume over the last 7 workouts</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer config={{ volume: { label: 'Volume (kg)', color: 'hsl(var(--primary))' } }}>
                    <ResponsiveContainer width="100%" height={300}>
                      <LineChart data={workoutChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Line type="monotone" dataKey="volume" stroke="hsl(var(--primary))" strokeWidth={2} />
                      </LineChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
            )}

            {runningChartData.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Running Distance Trend</CardTitle>
                  <CardDescription>Your running distances over the last 7 runs</CardDescription>
                </CardHeader>
                <CardContent>
                  <ChartContainer config={{ distance: { label: 'Distance (km)', color: 'hsl(var(--secondary))' } }}>
                    <ResponsiveContainer width="100%" height={300}>
                      <BarChart data={runningChartData}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <ChartTooltip content={<ChartTooltipContent />} />
                        <Bar dataKey="distance" fill="hsl(var(--secondary))" />
                      </BarChart>
                    </ResponsiveContainer>
                  </ChartContainer>
                </CardContent>
              </Card>
            )}

            <Card>
              <CardHeader>
                <CardTitle>Personal Records</CardTitle>
                <CardDescription>Your best lifts and runs</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-medium mb-2">Strength PRs</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>Bench Press</span>
                        <span className="font-medium">80kg</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Squat</span>
                        <span className="font-medium">100kg</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Deadlift</span>
                        <span className="font-medium">120kg</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium mb-2">Running PRs</h4>
                    <div className="space-y-1 text-sm">
                      <div className="flex justify-between">
                        <span>5K</span>
                        <span className="font-medium">22:30</span>
                      </div>
                      <div className="flex justify-between">
                        <span>10K</span>
                        <span className="font-medium">48:15</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Half Marathon</span>
                        <span className="font-medium">1:52:30</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}